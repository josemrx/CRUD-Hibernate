/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud.jd4o;

import crud.jd4o.Clases.Conexion;
import crud.jd4o.Clases.Proveedor;
import javax.security.auth.login.Configuration;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

/**
 *
 * @author user
 */
public class Prueba {
    
    
    public static void main(String[] args) {
        
        
        Conexion con = new Conexion();
        
        con.guardaProveedor(new Proveedor(0, "Pepe", "jaja", true));
        
    
    }
    
    
}
