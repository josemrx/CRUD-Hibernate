/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud.jd4o;

import crud.jd4o.Clases.Cliente;
import crud.jd4o.Clases.Conexion;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jose A
 */
public class TablaClientes{
    
    public void ver_tabla(JTable tabla){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        Conexion conexion = new Conexion();
        ArrayList<Cliente> lista = (ArrayList<Cliente>) conexion.DameTodosClientes();
        int posicion = 0;
        Object filas[][] = new Object[lista.size()][7];
        if(lista.size()>0){
            filas[posicion][2]="";
            for(Cliente rep :lista){
                JButton btn1 = new JButton("Ver");
                btn1.setName("v"+rep.getId());
                JButton btn2 = new JButton("Modificar");
                btn2.setName("m"+rep.getId());
                JButton btn3 = new JButton("Eliminar");
                btn3.setName("e"+rep.getId());
                filas[posicion][0] = rep.getId();
                filas[posicion][1] = rep.getNombre();
                filas[posicion][2] = rep.getRepuesto().getId();
                filas[posicion][3] = rep.getImporte();
                filas[posicion][4] = btn1;
                filas[posicion][5] = btn2;
                filas[posicion][6] = btn3;
                posicion++;
            }   
        }
        Object columnas[] = {"id","Nombre","Repuesto", "Importe", "Ver", "Modificar", "Eliminar"};
        
        DefaultTableModel d = new DefaultTableModel
        (
                filas,
                columnas
        )
        {
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabla.setModel(d);
        tabla.setPreferredScrollableViewportSize(tabla.getPreferredSize());
  

    }
}
