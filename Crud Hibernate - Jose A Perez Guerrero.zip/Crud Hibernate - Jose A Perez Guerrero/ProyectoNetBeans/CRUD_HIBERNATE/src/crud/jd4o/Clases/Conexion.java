/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud.jd4o.Clases;


import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


/**
 *
 * @author Jose A
 * 
 * 
 */
public class Conexion {
    

    private Session sesion;
    private Transaction tx;
    
    
    private void iniciaOperacion() throws HibernateException
    {
        sesion = HibernateUtil.getSessionFactory().openSession();
        tx = sesion.beginTransaction();
    }
    
    
    
    //Proveedores: No tienen foraneas de otras tablas-----------------------------------------------------------------------------
     public List<Proveedor> DameTodosProveedores(){
        List<Proveedor> listaContactos = null;  
        
        try 
        { 
            iniciaOperacion(); 
            listaContactos = sesion.createQuery("from Proveedor").list(); 
        }
        catch(Exception e){
            e.printStackTrace();
        }finally 
        { 
            sesion.close(); 
            return listaContactos;
            
        }  
 
    }
     
    public boolean guardaProveedor(Proveedor proveedor){
        try 
        { 
            iniciaOperacion(); 
            sesion.save(proveedor); 
            tx.commit(); 
            return true; 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
        finally 
        { 
            sesion.close(); 
        }  
    
    }
    public Proveedor dameProveedor(int id){
       
        Proveedor prov = null;  

        try 
        { 
            iniciaOperacion(); 
            prov = (Proveedor) sesion.get(Proveedor.class, id); 
        } 
        catch(Exception e){
            e.printStackTrace();
            
        }finally 
        { 
            sesion.close(); 
            return prov;
        }  
    }
    
   

    public boolean eliminaProveedor(int idProv) {
         Proveedor prov = null;  

        try 
        { 
            prov = dameProveedor(idProv);
            iniciaOperacion(); 
            sesion.delete(prov); 
            tx.commit(); 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }finally 
        { 
            sesion.close(); 
        }  
        return true;
    }

    public boolean modificaProveedor(Proveedor prov) {
    
        try 
        { 
            iniciaOperacion();  
            sesion.update(prov); 
            tx.commit(); 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }finally 
        { 
            sesion.close(); 
        }  
        return true;
    }
    
    //Repuestos: Foranea a la tabla Proveedores, restringido por BD-----------------------------------------------------------------------------
     public List<Repuesto> DameTodosRepuestos(){
        List<Repuesto> listaRepuestos = null;  
        try 
        { 
            iniciaOperacion(); 
            listaRepuestos = sesion.createQuery("from Repuesto").list(); 
        }
        catch(Exception e){
            e.printStackTrace();
        }finally 
        { 
            sesion.close(); 
            return listaRepuestos;
            
        }  
 
    }
     
    public boolean guardaRepuesto(Repuesto rep){
        try 
        { 
            iniciaOperacion(); 
            sesion.save(rep); 
            tx.commit(); 
            return true; 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
        finally 
        { 
            sesion.close(); 
        }  
    
    }
    public Repuesto dameRepuesto(int id){
       
        Repuesto rep = null;  

        try 
        { 
            iniciaOperacion(); 
            rep = (Repuesto) sesion.get(Repuesto.class, id); 
        } 
        catch(Exception e){
            e.printStackTrace();
            
        }finally 
        { 
            sesion.close(); 
            return rep;
        }  
    }
    
   

    public boolean eliminaRepuesto(int idRep) {
         Repuesto rep = null;  

        try 
        { 
            rep = dameRepuesto(idRep);
            iniciaOperacion(); 
            sesion.delete(rep); 
            tx.commit(); 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }finally 
        { 
            sesion.close(); 
        }  
        return true;
    }

    public boolean modificaRepuesto(Repuesto rep) {
    
        try 
        { 
            iniciaOperacion();  
            sesion.update(rep); 
            tx.commit(); 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }finally 
        { 
            sesion.close(); 
        }  
        return true;
    }
    
    //Clientes: Foranea a la tabla Repuestos, restringido por BD-----------------------------------------------------------------------------
     public List<Cliente> DameTodosClientes(){
        List<Cliente> listaClientes = null;  
        try 
        { 
            iniciaOperacion(); 
            listaClientes = sesion.createQuery("from Cliente").list(); 
        }
        catch(Exception e){
            e.printStackTrace();
        }finally 
        { 
            sesion.close(); 
            return listaClientes;
            
        }  
 
    }
     
    public boolean guardaCliente(Cliente cli){
        try 
        { 
            iniciaOperacion(); 
            sesion.save(cli); 
            tx.commit(); 
            return true; 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
        finally 
        { 
            sesion.close(); 
        }  
    
    }
    public Cliente dameCliente(int id){
       
        Cliente cli = null;  

        try 
        { 
            iniciaOperacion(); 
            cli = (Cliente) sesion.get(Cliente.class, id); 
        } 
        catch(Exception e){
            e.printStackTrace();
            
        }finally 
        { 
            sesion.close(); 
            return cli;
        }  
    }
    
   

    public boolean eliminaCliente(int idCli) {
         Cliente cli = null;  

        try 
        { 
            cli = dameCliente(idCli);
            iniciaOperacion(); 
            sesion.delete(cli); 
            tx.commit(); 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }finally 
        { 
            sesion.close(); 
        }  
        return true;
    }

    public boolean modificaCliente(Cliente cli) {
    
        try 
        { 
            iniciaOperacion();  
            sesion.update(cli); 
            tx.commit(); 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }finally 
        { 
            sesion.close(); 
        }  
        return true;
    }
    
    
    //Reparacion: Foranea a la tabla Repuestos, restringido por BD-----------------------------------------------------------------------------
     public List<Reparacion> DameTodasReparaciones(){
        List<Reparacion> listaReparaciones = null;  
        try 
        { 
            iniciaOperacion(); 
            listaReparaciones = sesion.createQuery("from Reparacion").list(); 
        }
        catch(Exception e){
            e.printStackTrace();
        }finally 
        { 
            sesion.close(); 
            return listaReparaciones;
            
        }  
 
    }
     
    public boolean guardaReparacion(Reparacion rep){
        try 
        { 
            iniciaOperacion(); 
            sesion.save(rep); 
            tx.commit(); 
            return true; 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
        finally 
        { 
            sesion.close(); 
        }  
    
    }
    public Reparacion dameReparacion(int id){
       
        Reparacion rep = null;  
        try 
        { 
            iniciaOperacion(); 
            rep = (Reparacion) sesion.get(Reparacion.class, id); 
        } 
        catch(Exception e){
            e.printStackTrace();
            
        }finally 
        { 
            sesion.close(); 
            return rep;
        }  
    }
    
   

    public boolean eliminaReparacion(int idRep) {
         Reparacion rep = null;  

        try 
        { 
            rep = dameReparacion(idRep);
            iniciaOperacion(); 
            sesion.delete(rep); 
            tx.commit(); 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }finally 
        { 
            sesion.close(); 
        }  
        return true;
    }

    public boolean modificaReparacion(Reparacion rep) {
    
        try 
        { 
            iniciaOperacion();  
            sesion.update(rep); 
            tx.commit(); 
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }finally 
        { 
            sesion.close(); 
        }  
        return true;
    }
    
   
    
}
