/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud.jd4o;

import crud.jd4o.Clases.Proveedor;
import crud.jd4o.Clases.Conexion;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Jose A
 */
public class TablaProveedores{
    
    public void ver_tabla(JTable tabla){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        Conexion conexion = new Conexion();
        ArrayList<Proveedor> lista = (ArrayList<Proveedor>) conexion.DameTodosProveedores();
        int posicion = 0;
        Object filas[][] = new Object[lista.size()][7];
        filas[posicion][2]="";
        for(Proveedor prov :lista){
            JButton btn1 = new JButton("Ver");
            btn1.setName("v"+prov.getId());
            JButton btn2 = new JButton("Modificar");
            btn2.setName("m"+prov.getId());
            JButton btn3 = new JButton("Eliminar");
            btn3.setName("e"+prov.getId());
            filas[posicion][0] = prov.getId();
            filas[posicion][1] = prov.getNombre();
            filas[posicion][2] = prov.getDireccion();
            filas[posicion][3] = prov.isDisponible();
            filas[posicion][4] = btn1;
            filas[posicion][5] = btn2;
            filas[posicion][6] = btn3;
            posicion++;
        }   
        Object columnas[] = {"id","Nombre","Direccion", "Disponible", "Ver", "Modificar", "Eliminar"};
        
        DefaultTableModel d = new DefaultTableModel
        (
                filas,
                columnas
        )
        {
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabla.setModel(d);
        tabla.setPreferredScrollableViewportSize(tabla.getPreferredSize());
  

    }
}
