
import crud.jd4o.Clases.Conexion;
import crud.jd4o.Clases.Proveedor;
import junit.framework.Assert;
import org.junit.Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jose A
 */
public class TDDConexion {
    
    
    //para ahcer los test debemos tener al menos uan fila con id=1 en todas las tablas
    
    @Test
    public final void pruebaInsertarProveedorDuplicado() {
        Conexion con = new Conexion();
        Assert.assertFalse("PruebaProveedorDuplicado:", con.guardaProveedor(con.dameProveedor(1)));
    }
    @Test
    public final void pruebaInsertarReparacionDuplicado() {
        Conexion con = new Conexion();
        Assert.assertFalse("PruebaProveedorDuplicado:", con.guardaReparacion(con.dameReparacion(1)));
    }
    @Test
    public final void pruebaBorrarClienteInexistente() {
        Conexion con = new Conexion();
        Assert.assertFalse("PruebaProveedorDuplicado:", con.eliminaCliente(24567));
    }
    @Test
    public final void pruebaBorraRepuestoEstandoEnOtraTabla() {
        Conexion con = new Conexion();
        Assert.assertFalse("PruebaProveedorDuplicado:", con.eliminaRepuesto(1));
    }
    @Test
    public final void pruebaModificarProveedorConExito() {
        Conexion con = new Conexion();
        Proveedor prov = con.dameProveedor(1);
        prov.setNombre("MODIFICADO TDD");
        Assert.assertTrue("PruebaProveedorDuplicado:", con.modificaProveedor(prov));
    }
    
    
}
